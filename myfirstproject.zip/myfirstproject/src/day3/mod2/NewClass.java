package day3.mod2;

public class NewClass {

    public static void main(String[] args) {
        Dog d = new Dog();

    }
}

class Dog {

    int weight;

    Dog() {
        System.out.println("dog is creating...");
    }

}
