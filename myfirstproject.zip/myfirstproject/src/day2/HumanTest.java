package day2;

public class HumanTest {

    public static void main(String[] args) {
        Human a = new Human();
        a.setAge(33);
        a.askDetail();
        a.ghoriDekheTimeBolo();
    }
}
