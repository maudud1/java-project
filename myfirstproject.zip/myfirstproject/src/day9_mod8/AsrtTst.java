/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package day9_mod8;

/**
 *
 * @author mbadiuzzaman
 */
public class AsrtTst {

    public static void main(String[] args) {
        System.out.println("first line");
        
        int jjj=4;

        assert jjj!=4 : "hhhhhhhhhhhh yyyyyyyyyy";

        System.out.println("thend");

    }
}
