/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package day1;

public class Emp {

    void callMe() {
        System.out.println("emps callme called...");
    }

    int calcAdd(int a, int b) {
        return (a + b);
    }
}
