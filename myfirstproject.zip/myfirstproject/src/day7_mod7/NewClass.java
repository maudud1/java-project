/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package day7_mod7;

/**
 *
 * @author mbadiuzzaman
 */
public class NewClass {

    void uuu() {
        int xx = 9;
        System.out.println(xx);
    }
}

class A {

    final int MY_FIN_VAR;

    A() {
        MY_FIN_VAR = 5;
    }

    A(int dd) {
        MY_FIN_VAR = xyz();
    }

    int xyz() {
        return 88;
    }

}

class B {

    void aaa() {
    }
}
