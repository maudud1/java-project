package day7_mod7;

public class Count4 {

    public static int counter;

    static {
        counter = Integer.getInteger("maudud").intValue();
    }
}
