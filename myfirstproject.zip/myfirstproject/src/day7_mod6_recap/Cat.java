/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package day7_mod6_recap;

/**
 *
 * @author mbadiuzzaman
 */
public class Cat {

    public Cat() {

    }
}
