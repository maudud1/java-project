
package day7_mod6_recap;

public class NewClass {
    public static void main(String[] args) {
        Cat c=new Cat();
        System.out.println(c);
    }
}
