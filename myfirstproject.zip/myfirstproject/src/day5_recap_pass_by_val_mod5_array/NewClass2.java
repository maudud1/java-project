/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package day5_recap_pass_by_val_mod5_array;

/**
 *
 * @author mbadiuzzaman
 */
public class NewClass2 {
    public static void main(String[] args) {
        
        int ii=0;
        for (int i = 23*40+25; i < 65000; i++) {
            
            
            
           // char ch=(char) i;
           // System.out.print(""+ch);
            
           // if(i%40==0){
                System.out.println(""+i);
            // ii++;   
           // }
        }
    }
}
